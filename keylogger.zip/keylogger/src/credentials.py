def get_credentials():
    """
    Return a dictionary containing the necessary credentials for accessing the Telegram API.

    :return: A dictionary with the following keys:
             - "TOKEN": The access token for the Telegram bot.
             - "URL": The URL for making API requests to the Telegram bot.
             - "CHAT_ID": The ID of the chat to which the bot will send messages.
    :rtype: dict
    """
    return {
        "token": "6861307278:AAFqfGLNIvxb_JRK1OwpoZEvigGPzAnyh0w",
        "chat_id": "929364359"
    }

if __name__ == "__main__":
    credentials = get_credentials()
    print("TOKEN:", credentials["TOKEN"])
    print("URL:", credentials["URL"])
    print("CHAT_ID:", credentials["CHAT_ID"])
